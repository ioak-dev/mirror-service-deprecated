from django.apps import AppConfig


class DeeplearningConfig(AppConfig):
    name = 'deeplearning'
